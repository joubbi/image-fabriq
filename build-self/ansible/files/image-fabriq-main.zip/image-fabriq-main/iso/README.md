## Place installation media files in this directory.
Packer will place downloaded iso files here as well.

