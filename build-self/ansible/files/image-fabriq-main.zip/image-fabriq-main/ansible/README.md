These Ansible playbooks and files are used by image-fabriq when building images.


Author Information
------------------

Written by [Farid Joubbi](https://github.com/faridjoubbi) - Conoa AB - https://conoa.se
