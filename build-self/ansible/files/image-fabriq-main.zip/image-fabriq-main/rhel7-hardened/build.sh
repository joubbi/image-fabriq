#!/usr/bin/env bash
PACKER_CACHE_DIR=../packer_cache/ /usr/bin/packer build rhel7-hardened.json 
