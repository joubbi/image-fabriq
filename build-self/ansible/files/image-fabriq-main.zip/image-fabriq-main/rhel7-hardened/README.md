# Red Hat Enterprise Linux 7 hardened image


This fabriq creates a hardened RHEL 7.


See the centos7-hardened [README](../centos7-hardened/README.md).


Author Information
------------------

Written by [Farid Joubbi](https://github.com/faridjoubbi) - Conoa AB - https://conoa.se

