# Red Hat Enterprise Linux 8 hardened image


This fabriq creates a hardened RHEL 8.


See the centos8-hardened [README](../centos8-hardened/README.md).


Author Information
------------------

Written by [Farid Joubbi](https://github.com/faridjoubbi) - Conoa AB - https://conoa.se

