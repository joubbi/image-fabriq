#!/usr/bin/env bash
PACKER_CACHE_DIR=../packer_cache/ /usr/bin/packer build centos8-hardened.json 
